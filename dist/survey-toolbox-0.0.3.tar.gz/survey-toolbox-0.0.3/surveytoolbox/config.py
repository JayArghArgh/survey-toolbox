EASTING = "e"
NORTHING = "n"
ELEVATION = "el"
BEARING = 'bg'
DIST_2D = 'dist_2d'
DIST_3D = 'dist_3d'
